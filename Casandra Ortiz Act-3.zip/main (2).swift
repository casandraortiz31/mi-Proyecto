import Foundation

var aux: String = ""
var opcionIngresada: String = aux
var saldototal: Double = 0

func deposito() {
    print("Ingresa la cantidad a depositar:")
    print("\n")

    aux = readLine()!
    opcionIngresada = aux

    if let cantidadIngresada = Double(opcionIngresada) {
        saldototal += cantidadIngresada
        print("Abono exitoso por $\(cantidadIngresada)")
        print("Tu saldo actual es de $\(saldototal)")
    } else {
        print("Introduce una cantidad válida, serás dirigido al menú principal")
    }
}

func retiro() {
    print("Ingresa la cantidad a retirar:")
    print("\n")

    aux = readLine()!
    opcionIngresada = aux

    if let cantidadRetirar = Double(opcionIngresada) {

        if cantidadRetirar <= saldototal && cantidadRetirar > 0 {

            print("Retiro exitoso por $\(cantidadRetirar)")

            saldototal = saldototal - cantidadRetirar

            print("Saldo actual: $\(saldototal)")

        } else {

            print("Lo siento, la cantidad que quieres retirar excede el límite de saldo disponible")
        }

    } else {

        print("Cantidad no válida")
    }
}

while opcionIngresada != "4" {

    print("\n")
    print("***** BANCO COPPEL *******")
    print("\n")
    print("1.- Depósito")
    print("2.- Retiro")
    print("3.- Consultar saldo")
    print("4.- Salir")

    aux = readLine()!
    opcionIngresada = aux

    switch opcionIngresada {

    case "1":

        deposito()

        print("\n")
        print("¿Deseas realizar otro depósito? (S/N): ")

        aux = readLine()!
        opcionIngresada = aux

        switch opcionIngresada {

        case "S":
            deposito()

        case "N":

            print("¿Deseas continuar con otra operación? (N/S)")

            aux = readLine()!
            opcionIngresada = aux

            if opcionIngresada == "N" {
                print("Cerrando sesión, vuelva pronto")
                opcionIngresada = "4"
            }

        default:
            print("\n")
        }

    case "2":

        retiro()

        print("\n")
        print("¿Deseas realizar otro retiro? (S/N): ")

        aux = readLine()!
        opcionIngresada = aux

        switch opcionIngresada {

        case "S", "s", "Si", "SI", "sI", "si":
            retiro()

        case "N", "n", "No", "NO", "nO", "no":

            print("¿Deseas continuar con otra operación? (N/S)")

            aux = readLine()!
            opcionIngresada = aux

            if opcionIngresada == "N" {
                print("Cerrando sesión, vuelva pronto")
                opcionIngresada = "4"
            }

        default:
            print("Opción no válida")
        }

    case "3":

        print("Saldo actual: $\(saldototal) pesos")
        print("\n")
        print("¿Deseas realizar otro depósito? (S/N)")

        aux = readLine()!
        opcionIngresada = aux

        switch opcionIngresada {
        //case "S", "s", "Si", "SI", "sI", "si":
        //print("regresando al mernu principal")

        case "N", "n", "No", "NO", "nO", "no":
         print("Cerrando sesión, vuelva pronto!")
         opcionIngresada = "4"

        default:
            print("\n")
        }

    case "4":

        print("Cerrando sesión, vuelva pronto!")

    default:

        print("No valida")
    }
}