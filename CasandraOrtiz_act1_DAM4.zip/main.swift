struct Articulo {
    let nombre: String?
    let precio: Int?
    let stock: Int?
}

// arreglo de articutario de la tienda
var articulos = [
    Articulo(nombre: "Zapatos", precio: 500, stock:10),
    Articulo(nombre: "Playeras", precio: 400, stock:40),
    Articulo(nombre: "Pantalones", precio: 50, stock:50),
    Articulo(nombre: "Zombrero", precio: 140, stock:5),
    Articulo(nombre: "Pantallas", precio: 3500, stock:10)
]

var aux: String = ""
var opcionIngresada: String = aux
var cuenta: Int = 0

//Menu interactivo}
while opcionIngresada != "2" {
    print("*******BIENVENIDOS A COPPEL********")
    print("*****ARTICULOS*********")
    print(" ----------")
    print("Articulos 1 \(articulos[0].nombre!)")
    print("Precio: \(articulos[0].precio!)")
    print("Stock \(articulos[0].stock!):")
    print("_______________________________")
    
    print("Articulos 2 \(articulos[1].nombre!): ")
    print("Precio \(articulos[1].precio!): ")
    print("Stock \(articulos[1].stock!): ")
    print("_______________________________")
    
    print("Articulos 3 \(articulos[2].nombre!) ")
    print("Precio \(articulos[2].precio!) ")
    print("Stock \(articulos[2].stock!) ")
    print("_______________________________")
    
    print("Articulos 4 \(articulos[3].nombre!) ")
    print("Precio \(articulos[3].precio!) ")
    print("Stock \(articulos[3].stock!) ")
    print("_______________________________")
    
    print("1.- Comprar articulo")
    print("2.- Salir")
    
    aux = readLine()!
    opcionIngresada = aux
    
    switch opcionIngresada{
        case "1":
        print("ingresa la cantidad de \(articulos[0].nombre!) que desea comprar: ")
        
        aux = readLine()!
        opcionIngresada = aux
        
        let cantidadIngresada = Int(opcionIngresada)!//Force unwrap
        if cantidadIngresada <= articulos[0].stock! {
            cuenta = cantidadIngresada * articulos[0].precio!
            print("TOTAL A PAGAR: $\(cuenta)")
            print("\n**********GRACIAS POR SU COMPRA, VUELVA PRONTO A************")
        } else {
            print(" No hay suficiente stock, lo sentimos!")
        }
        
        default:
        print("No valido")
    }
    
    
}